/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file misc.c
/// \author Renan Sterle - R.A.: 176536
/// \brief Implements miscellaneous routines used by IAS assembler.
///

#include "misc.h"

bool Alphanumeric(char *S)
{
	if (!isalpha(S[0]))
	{
		return false;
	}
	while (*S)
	{
		if (!isalnum(*S) && *S != '_')
		{
			return false;
		}
		S++;
	}
	return true;
}

bool IsNumber(char *String, int Base, long *Value)
{
	if (Base == 16 && (strlen(String) != 12))
	{
		return false;
	}
	char* P;
	if (Value)
	{
		*Value = strtol(String, &P, Base);
	}
	else
	{
		strtol(String, &P, Base);
	}
	return !(*P);
}

void Substring(char **String, char *Begin, int N)
{
	if (String && *String)
	{
		///Allocates new string with correct size.
		char *New = (char*)malloc((Begin-*String+N+1)*sizeof(char)), *D = New;
		///Copies interesting elements.
		for (char *It = Begin; It < Begin+N && *It; It++)
		{
			*D++ = *It;
		}
		*D = 0;
		///Releases old one.
		free(*String);
		///And assignes old one to the new one, as if nothing had happended.
		*String = New;
		String = &New;
	}
}

void Error(int Line, const char *Context, const char *Error)
{
	/// \note Error output would preferably be stderr, but SuSy just won't consider that.
	/// If a positive line number is provided, it is displayed. Some errors don't have line	number.
	if (Line >= 0)
	{
		fprintf(stdout, "ERROR on line %d\n", Line);
	}
	else
	{
		fprintf(stdout, "ERROR\n");
	}
	/// If a valid content is provided, it is displayed.
	if (Context)
	{
		fprintf(stdout, "\"%s\"", Context);
	}
	/// Displays error message.
	fprintf(stdout, "%s\n", Error);

	/// \note Aborts program.
	exit(0);
}

char **LowerBound (const char **Begin, const char **End, char *Key)
{
	/// Performs simple lower bound search.
	char **I = (char**)Begin, **Middle, Dist = (End-Begin);
	/// While not in position:
	while (Dist > 0)
	{
		Middle = I + Dist/2;
		if (strcmp(*Middle, Key) < 0)
		{
			/// Switches to the right half.
			I = ++Middle;
			Dist -= Dist/2+1;
		}
		else
		{
			/// Switches to the left half.
			Dist = Dist/2;
		}
	}
	return I;
}

int *NewInt(int Old)
{
	int *New = (int*)malloc(sizeof(int));
	*New = Old;
	return New;
}

char *NewString(char *Old)
{
	char *New = (char*)malloc((strlen(Old)+1)*sizeof(char));
	strcpy(New, Old);
	return New;
}

int StringComparator(void *A, void *B)
{
	/// \note Simple wrapper of strcmp. Used just to avoid invalid pointer types warnings.
	return strcmp((char*)A, (char*)B);
}

int IntComparator(void *A, void *B)
{
	///Similar to strcmp, but for integers.
	if (*(int*)A > *(int*)B)
	{
		return 1;
	}
	else if (*(int*)A < *(int*)B)
	{
		return -1;
	}
	return 0;
}

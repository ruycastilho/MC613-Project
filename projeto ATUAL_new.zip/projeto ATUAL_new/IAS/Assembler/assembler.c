/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file assembler.c
/// \author Renan Sterle - R.A.: 176536
/// \brief Implements routines used by IAS assembler.
///
///  \note Memory deallocation is perfectly functional when the assembly can be completed. In case there
/// is an error within input file, the memory map is not generated and the program is aborted without
/// explicitly deallocating memory. Though, thats no problem considering the assembler the final stage
/// on the whole compilation process and, specially, as the compilation is aborted when the input file
/// has an error. Still, implementing complete deallocation in every case is desirable, but would torn
/// code less elegant.
///

#include "assembler.h"

///
/// \todo Release all memory even when assembly fails.											Pending
/// \todo Print error messages to stdout, not stderr											OK
/// \todo Check error messages line numbers, mayber some of them are wrong.						OK
/// \todo Comment and organise everything properly.												Pending
/// \todo Check structure [Label][Instruction] or [Label][Directive][Parameters], assuming
///																	separation by sentences.	OK
///

bool IsDirective(char *Directive)
{
	/// \note Note usage of binary search through LowerBound.
	char **Position = LowerBound(Directives, Directives+NumberDirectives, Directive);
	return (Position < (char**)Directives+NumberDirectives && !strcmp(*Position, Directive));
}

bool IsInstruction(char *Instruction)
{
	/// \note Note usage of binary search through LowerBound.
	char **Position = LowerBound(Instructions, Instructions+NumberInstructions, Instruction);
	return (Position < (char**)Instructions+NumberInstructions && !strcmp(*Position, Instruction));
}

int GetOpCode(char *Instruction)
{
	/// \note Note usage of binary search through LowerBound.
	char **Position = LowerBound(Instructions, Instructions+NumberInstructions, Instruction);
	if (Position < (char**)Instructions+NumberInstructions && !strcmp(*Position, Instruction))
	{
		return OpCodes[(const char**)Position-Instructions];
	}
	return -1;
}

void VerifySentenceOrder(ListIterator Begin)
{
	/// For each sentence from Begin until the end of the list, checks order of tokens
	/// using a FSM abstraction. If stage 6 is trespassed, the sentence is invalid.
	int Stage = 0;
	while (Begin)
	{
		TToken *Token = (TToken*)(Begin->Data);
		switch (Stage)
		{
			case 0: ///First position: Accepts label, instruction or directive only.
				switch (Token->Type)
				{
					case label:
						Stage = 1;
						break;
					case instruction:
						Stage = 2;
						break;
					case directive:
						Stage = 4;
						break;
					default:
						Error(Token->Line, Token->Text, ": token unexpected. 0");
				}
				break;
			case 1: ///After firts label: Accepts instruction or directive only.
				switch (Token->Type)
				{
					case instruction:
						Stage = 2;
						break;
					case directive:
						Stage = 4;
						break;
					default:
						Error(Token->Line, Token->Text, ": token unexpected. 1");
				}
				break;
			case 2: ///After instruction: Accepts address or directive only.
				if (Token->Type & address)
				{
					Stage = 4;
				}
				else if (Token->Type == directive)
				{
					Stage = 4;
				}
				else
				{
					Error(Token->Line, Token->Text, ": token unexpected. 2");
				}
				break;
			case 3: ///After address: Accepts directive only.
				if (Token->Type == directive)
				{
					Stage = 4;
				}
				else
				{
					Error(Token->Line, Token->Text, ": token unexpected. 3");
				}
				break;
			case 4: ///After directive: Accepts symbol or literal only.
				if (Token->Type == symbol || Token->Type & literal)
				{
					Stage = 5;
				}
				else
				{
					Error(Token->Line, Token->Text, ": token unexpected. 4");
				}
				break;
			case 5: ///After first direcrive parameter: Accepts symbol or literal only.
				if (Token->Type == symbol || Token->Type & literal)
				{
					Stage = 6;
				}
				else
				{
					Error(Token->Line, Token->Text, ": token unexpected. 5");
				}
				break;
			default: ///After second directive: Accepts anything.
				Error(Token->Line, Token->Text, ": token unexpected. 6");
		}
		Begin = Begin->Next;
	}
}

void ReadFile(TList *Tokens, const char *Address)
{
	FILE *File = fopen(Address, "r");
	if (!File)
	{
		Error(-1, NULL, "No such file. 7");
	}
	/// If file opening is successful, reads stream line by line.
	char* Line = (char*)malloc(MaxLineLength*sizeof(char));
	int LineNumber = 0;
	ListIterator Last = NULL;
	while (fgets(Line, MaxLineLength, File))
	{
		/// Tokenizing each line.
		LineNumber++;
		char *Token = strtok(Line,"\t \n");
		while (Token)
		{
			/// Removing anything after '#'.
			char *Position = strchr(Token, '#');
			if (Position)
			{
				if (Position-Token)
				{
					*Position = 0;
					/// And inserting tokens to Tokens.
					ListPushBack(Tokens, NewTokenB(Token, LineNumber));
				}
				break;
			}
			else
			{
				/// And inserting tokens to Tokens.
				ListPushBack(Tokens, NewTokenB(Token, LineNumber));
			}
			if (!Last)
			{
				Last = Tokens->Tail;
			}
			Token = strtok(NULL, "\t \n");
		}
		///	And evaluating each sentence.
		VerifySentenceOrder(Last);
		Last = NULL;
	}
	free(Line);
	fclose(File);
}

TokenType ClassifyToken(char **Token, int Line)
{
	/// For each character in Token:
	size_t Length = strlen(*Token);
	for (char *It = *Token; *It; It++)
	{
		///If is ':', it must be a label.
		if (*It == ':')
		{
			Substring(Token, *Token, --Length);
			/// Checks if token is a valid label.
			if (!Length || !Alphanumeric(*Token))
			{
				Error(Line, *Token, " is not a valid label. 8");
			}
			return label;
		}
		///If is '.', it must be a directive.
		else if (*It == '.')
		{
			/// Checks if token is a valid directive.
			if (IsDirective(*Token))
			{
				return directive;
			}
			Error(Line, *Token, " is not a valid directive. 9");
		}
		///If is '"', it must be an address.
		else if (*It == '"')
		{
			///Cheks formatting.
			if (It != *Token || (*Token)[Length-1] != '"')
			{
				Error(Line, *Token, " is not a valid address. 10");
			}
			///Eliminates '"'.
			Substring(Token, (*Token+1), Length-2);
			///Cheks if is a label,
			if (Alphanumeric(*Token))
			{
				return (TokenType)(address | label);
			}
			///A decimal number,
			else if (IsNumber(*Token, 10, NULL))
			{
				return (TokenType)(address | decimal);
			}
			///Or an hexadecimal number.
			else if (IsNumber(*Token, 16, NULL))
			{
				return (TokenType)(address | hexadecimal);
			}
			else
			{
				Error(Line, *Token, " is not a valid address. 11");
			}
		}
	}
	///Is in instructions set, is an instruction.
	if (IsInstruction(*Token))
	{
		return instruction;
	}
	///Is a valid symbol.
	if (Alphanumeric(*Token))
	{
		return symbol;
	}
	///Is a valid decimal literal.
	else if (IsNumber(*Token, 10, NULL))
	{
		return (TokenType)(literal | decimal);
	}
	///Is a valid hexadecimal literal.
	else if (IsNumber(*Token, 16, NULL))
	{
		return (TokenType)(literal | hexadecimal);
	}
	Error(Line, *Token, ": Invalid token. 12");
	return invalid;
}

void PreProcessing(TList *Tokens)
{
	/// For each token It in Tokens:
	for (ListIterator It = Tokens->Head; It;)
	{
		TToken Token = *(TToken*)(It->Data);
		/// If it is a .set directive...
		if (Token.Type == directive && !strcmp(Token.Text, ".set"))
		{
			int Line = Token.Line;
			///Removes it from Tokens.
			ListErase(Tokens, &It);
			if (!It)
			{
				Error(Line, NULL, "Symbol expected. 13");
			}
			///Verifies its first parameter validity.
			TToken *ParameterA = NewTokenA((TToken*)(It->Data));
			if (ParameterA->Type != symbol)
			{
				Error(ParameterA->Line, ParameterA->Text, ": symbol expected. 14");
			}
			///Removes its first parameter from Tokens.
			ListErase(Tokens, &It);
			if (!It)
			{
				Error(Line, NULL, "Literal expected. 15");
			}
			///Verifies its second parameter validity.
			TToken *ParameterB = NewTokenA((TToken*)(It->Data));
			if (!(ParameterB->Type & literal))
			{
				Error(ParameterB->Line, ParameterB->Text, ": literal expected. 16");
			}
			if (ParameterB->Type & decimal)
			{
				long Number;
				IsNumber(ParameterB->Text, 10, &Number);
				if (Number >= 0x80000000L || Number < 0)
				{
					Error(ParameterB->Line, ParameterB->Text, ": invalid decimal literal range. 17");
				}
			}
			///Removes its second parameter from Tokens.
			ListErase(Tokens, &It);
			///Replaces every occurence until end of Tokens.
			for (ListIterator Ij = It; Ij; Ij = Ij->Next)
			{
				TToken *Target = NewTokenA((TToken*)(Ij->Data));
				if (Target->Type == symbol && !strcmp(Target->Text, ParameterA->Text))
				{
					TokenDestructor((TToken*)Ij->Data);
					Ij->Data = NewTokenC(ParameterB->Text, Target->Line, ParameterB->Type);
				}
				TokenDestructor(Target);
			}
			TokenDestructor(ParameterA);
			TokenDestructor(ParameterB);
		}
		else
		{
			It = It->Next;
		}
	}
}

void AssembleInstruction(ListIterator *It, RBTree *LabelMap, RBTree *DependentInstructions, RBTree *Memory, int *Index)
{
	TToken *Token = (TToken*)((*It)->Data);
	long OpCode = GetOpCode(Token->Text), Address = 0;
	///Instructions with op. code different to 10, 20 or 21 need an address.
	if ((OpCode != 10) && (OpCode != 20) && (OpCode != 21))
	{
		int Line = Token->Line;
		///Verifies if there is a following token.
		*It = (*It)->Next;
		if (!*It)
		{
			Error(Line, NULL, "Address expected. 18");
		}
		///And if it is a valid address.
		TToken *Parameter = (TToken*)((*It)->Data);
		if (!(Parameter->Type & address))
		{
			Error(Parameter->Line, Parameter->Text, ": address expected. 19");
		}
		if (Parameter->Type & label)
		{
			///In case it is a label,
			RBTreeIterator Iu = RBTreeFind(LabelMap, Parameter->Text);
			///Cheks if it is defined.
			if (!Iu)
			{
				///If it is still not defined, adds instruction to pendency record.
				Iu = RBTreeFind(DependentInstructions, Parameter->Text);
				if (!Iu)
				{
					Iu = RBTreeInsert(DependentInstructions, NewString(Parameter->Text), ConstructList(free));
					///Keeping line number of firts occurence.
					ListPushBack((TList*)(Iu->Data), NewInt(Parameter->Line));
				}
				ListPushBack((TList*)(Iu->Data), NewInt(*Index));
				RBTreeInsert(Memory, NewInt((*Index)++), NewTWordB(OpCode, 0));
				return;
			}
			else
			{
				///Retrives address.
				Address = *(int*)(Iu->Data);
			}
		}
		else
		{
			///In case it is a number, checks validity and retrieves value.
			IsNumber(Parameter->Text, ((Parameter->Type & decimal) ? 10 : 16), &Address);
			Address <<= 1;
			if ((Parameter->Type & decimal) && (Address < 0 || Address >= MemorySize))
			{
				Error(Parameter->Line, Parameter->Text, ": invalid number. 20");
			}
		}
		/// \note Op. code depends on address for JMP, JUMP+ and STaddr.
		if (OpCode == 14 || OpCode == 19 || OpCode == 16)
		{
			/// If necessaur, updates op. code.
			if (!(Address & 1))
			{
				OpCode --;
			}
		}
	}
	///Inserts instruction to memory map.
	RBTreeInsert(Memory, NewInt((*Index)++), NewTWordB(OpCode, Address >> 1));
}

void PerformDirective(ListIterator *It, RBTree *LabelMap, RBTree *DependentValues, RBTree *Memory, int *Index)
{
	TToken *Token = (TToken*)((*It)->Data);
	if (!strcmp(Token->Text, ".org"))
	{
		///If the token Token given by It is .org directive with a parameter...
		int Line = Token->Line;
		*It = (*It)->Next;
		if (!*It)
		{
			Error(Line, NULL, "Literal expected. 21");
		}
		///Verifies parameter validity and...
		TToken *Parameter = (TToken*)((*It)->Data);
		if (!(Parameter->Type & literal))
		{
			Error(Parameter->Line, Parameter->Text, ": literal expected. 22");
		}
		long Address;
		IsNumber(Parameter->Text, ((Parameter->Type & decimal) ? 10 : 16), &Address);
		if (Address < 0 || Address*2 >= MemorySize)
		{
			Error(Parameter->Line, Parameter->Text, ": invalid address. 23");
		}
		///Updates memory index.
		*Index = Address << 1;
	}
	else if (!strcmp(Token->Text, ".align"))
	{
		///If the token Token given by It is .align directive with a parameter...
		int Line = Token->Line;
		*It = (*It)->Next;
		if (!*It)
		{
			Error(Line, NULL, "Literal expected. 24");
		}
		///Verifies parameter validity and...
		TToken *Parameter = (TToken*)((*It)->Data);
		if (!(Parameter->Type & decimal))
		{
			Error(Parameter->Line, Parameter->Text, ": decimal literal expected. 25");
		}
		long N;
		IsNumber(Parameter->Text, 10, &N);
		if (N < 1 || N*2 >= MemorySize)
		{
			Error(Parameter->Line, Parameter->Text, ": invalid parameter. 26");
		}
		///Updates memory index.
		if ((*Index & 1) || ((*Index >> 1) % N))
		{
			(*Index) = (((*Index) / (2*N)) + 1) * 2*N;
		}
		if (*Index >= MemorySize)
		{
			Error(Parameter->Line, Parameter->Text, ": invalid number for .align from this position. 27");
		}
	}
	else if (!strcmp(Token->Text, ".word"))
	{
		///If the token Token given by It is .word directive with a parameter...
		int Line = Token->Line;
		if ((*Index & 1) || *Index >= MemorySize)
		{
			Error(Line, NULL, ".word: Invalid position. 28");
		}
		*It = (*It)->Next;
		if (!*It)
		{
			Error(Line, NULL, "Literal or label expected. 29");
		}
		///Verifies parameter validity and...
		TToken *Parameter = (TToken*)((*It)->Data);
		if ((!(Parameter->Type & literal) && !(Parameter->Type & symbol)))
		{
			Error(Parameter->Line, Parameter->Text, ": literal or label expected. 30");
		}
		if (Parameter->Type & symbol)
		{
			///In case the parameter is a label.
			RBTreeIterator Iu = RBTreeFind(LabelMap, Parameter->Text);
			if (!Iu)
			{
				///If it is still not defined, a dependency registry is added.
				RBTreeIterator Iv = RBTreeFind(DependentValues, Parameter->Text);
				if (!Iv)
				{
					Iv = RBTreeInsert(DependentValues, NewString(Parameter->Text), ConstructList(free));
					///The line number of first occurence is kept.
					ListPushBack((TList*)(Iv->Data), NewInt(Parameter->Line));
				}
				ListPushBack((TList*)(Iv->Data), NewInt(*Index));
				*Index += 2;
			}
			else
			{
				///If it is already defined, inserts corresping word in memory.
				RBTreeInsert(Memory, NewInt((*Index)++), NewTWordA((*(int*)(Iu->Data) >> 1) >> 20 & 0xFFFFF));
				RBTreeInsert(Memory, NewInt((*Index)++), NewTWordA((*(int*)(Iu->Data) >> 1) & 0xFFFFF));
			}
		}
		else
		{
			///In case the parameter is a literal, inserts the corresponding word in memory.
			long Value;
			IsNumber(Parameter->Text, ((Parameter->Type & decimal) ? 10 : 16), &Value);
			if ((Parameter->Type & decimal) && ((Value < 0) || (Value >= 0x100000000L)))
			{
				Error(Parameter->Line, Parameter->Text, ": invalid decimal literal range. 31");
			}
			RBTreeInsert(Memory, NewInt((*Index)++), NewTWordA(Value >> 20 & 0xFFFFF));
			RBTreeInsert(Memory, NewInt((*Index)++), NewTWordA(Value & 0xFFFFF));
		}
	}
	else if (!strcmp(Token->Text, ".wfill"))
	{
		///If the token Token given by It is .wfill directive with two parameters...
		int Line = Token->Line;
		if (*Index & 1)
		{
			Error(Line, NULL, ".wfill: Invalid position. 32");
		}
		///Checks wether the first parameter is valid.
		*It = (*It)->Next;
		if (!*It)
		{
			Error(Line, NULL, "Decimal literal expected. 33");
		}
		TToken *ParameterA = (TToken*)((*It)->Data);
		if (!(ParameterA->Type & decimal))
		{
			Error(ParameterA->Line, ParameterA->Text, ": decimal literal expected. 34");
		}
		long Times;
		IsNumber(ParameterA->Text, 10, &Times);
		if (Times < 1 || 2*Times+(*Index) >= MemorySize)
		{
			Error(ParameterA->Line, NULL, "There is no space for .wfill of this size from this position. 35");
		}
		///Checks wether the second parameter is valid.
		*It = (*It)->Next;
		if (!*It)
		{
			Error(ParameterA->Line, NULL, "Literal or label expected. 36");
		}
		TToken *ParameterB = (TToken*)((*It)->Data);
		if ((!(ParameterB->Type & literal) && !(ParameterB->Type & symbol)))
		{
			Error(ParameterB->Line, ParameterB->Text, ": literal or label expected. 37");
		}
		if (ParameterB->Type & symbol)
		{
			///If second parameter is a symbol...
			RBTreeIterator Iu = RBTreeFind(LabelMap, ParameterB->Text);
			if (!Iu)
			{
				///If it is still not defined.
				for (int I = 0; I < Times; I++)
				{
					///Registers dependecy for further replacement.
					RBTreeIterator Iv = RBTreeFind(DependentValues, ParameterB->Text);
					if (!Iv)
					{
						Iv = RBTreeInsert(DependentValues, NewString(ParameterB->Text), ConstructList(free));
						///Keeps the line number of first occurence.
						ListPushBack((TList*)(Iv->Data), NewInt(ParameterB->Line));
					}
					ListPushBack((TList*)(Iv->Data), NewInt(*Index));
					*Index += 2;
				}
			}
			else
			{
				///It is already defined. It is only necessary to write Times words to memory.
				for (int I = 0; I < Times; I++)
				{
					RBTreeInsert(Memory, NewInt((*Index)++), NewTWordA((*(int*)(Iu->Data) >> 1) >> 20 & 0xFFFFF));
					RBTreeInsert(Memory, NewInt((*Index)++), NewTWordA((*(int*)(Iu->Data) >> 1) & 0xFFFFF));
				}
			}
		}
		else
		{
			long Value;
			IsNumber(ParameterB->Text, ((ParameterB->Type & decimal) ? 10 : 16), &Value);
			if ((ParameterB->Type & decimal) && ((Value >= 0x80000000L) || (Value < -0x80000000L)))
			{
				Error(ParameterB->Line, ParameterB->Text, ": invalid decimal literal range. 38");
			}
			///The second parameter is a numeric literal. Thus, the words can be inserted in memory directly.
			for (int I = 0; I < Times; I++)
			{
				RBTreeInsert(Memory, NewInt((*Index)++), NewTWordA(Value >> 20 & 0xFFFFF));
				RBTreeInsert(Memory, NewInt((*Index)++), NewTWordA(Value & 0xFFFFF));
			}
		}
	}
}

void ReplaceAddresses(RBTree *LabelMap, RBTree *DependentInstructions, RBTree *Memory)
{
	///For each entry in DependentInstructions;
	for (RBTreeIterator It = DependentInstructions->Begin; It; It = RBTreeNextIterator(DependentInstructions, It))
	{
		///Checks if the label has finally been defined.
		RBTreeIterator Iu = RBTreeFind(LabelMap, It->Key);
		if (!Iu)
		{
			Error(*(int*)(((TList*)(It->Data))->Head->Data), (char*)It->Key, ": Label not defined. 39");
		}
		///And replaces address on every dependent instruction, updating opcode if necessary.
		int Address = *(int*)Iu->Data, OpCode;
		for (ListIterator Ij = ((TList*)(It->Data))->Head->Next; Ij; Ij = Ij->Next)
		{
			Iu = RBTreeFind(Memory, Ij->Data);
			if (Iu)
			{
				OpCode = ((TWord*)(Iu->Data))->OpCode;
				///Op. code depends on address.
				if (OpCode == 14 || OpCode == 19 || OpCode == 16)
				{
					if (!(Address & 1))
					{
						OpCode --;
					}
				}
				RBTreeInsert(Memory, NewInt(*(int*)Ij->Data), NewTWordB(OpCode, Address	>> 1));
			}
		}
	}
}

void ReplaceValues(RBTree *LabelMap, RBTree *DependentValues, RBTree *Memory)
{
	///For each entry in DependentValue;
	for (RBTreeIterator It = DependentValues->Begin; It; It = RBTreeNextIterator(DependentValues, It))
	{
		///Checks if the label has finally been defined.
		RBTreeIterator Iu = RBTreeFind(LabelMap, It->Key);
		if (!Iu)
		{
			Error(*(int*)(((TList*)(It->Data))->Head->Data), (char*)It->Key, ": Symbol or label not defined. 40");
		}
		///And inserts every dependent word.
		int Value = *(int*)Iu->Data >> 1;
		for (ListIterator Ij = ((TList*)(It->Data))->Head->Next; Ij; Ij = Ij->Next)
		{
			int Index = *(int*)(Ij->Data);
			RBTreeInsert(Memory, NewInt(Index++), NewTWordA(Value >> 20 & 0xFFFFF));
			RBTreeInsert(Memory, NewInt(Index++), NewTWordA(Value & 0xFFFFF));
		}
	}
}

void CompleteMemory(RBTree *Memory)
{
	if (Memory->Size)
	{
		///For each half word in memory,
		int Last = *(int*)(Memory->Begin->Key);
		for (RBTreeIterator It = Memory->Begin; It; It = RBTreeNextIterator(Memory, It))
		{
			///Checks if the previous,
			int Index = *(int*)(It->Key);
			if (Index - Last > 1)
			{
				///when the half word is in right, is missing.
				if (Index & 1)
				{
					if (Last & 1)
					{
						///And completes, if necessary.
						RBTreeInsert(Memory, NewInt(Index-1), NewTWordA(0));
					}
				}
				///Or the next, when the half word is in left, is missing.
				else
				{
					///And completes, if necessary.
					if (!(Last & 1))
					{
						RBTreeInsert(Memory, NewInt(Last+1), NewTWordA(0));
					}
				}
			}
			Last = Index;
		}
		///In case the last half word is on left, adds an empty right word right after it.
		if (!(Last & 1))
		{
			RBTreeInsert(Memory, NewInt(Last+1), NewTWordA(0));
		}
	}
}

void Assemble(TList *Tokens, RBTree *LabelMap, RBTree *DependentInstructions, RBTree *DependentValues, RBTree *Memory)
{
	///For each token in Tokens, base on it type, applys the proper assembly routine.
	int Index = 0;
	for (ListIterator It = Tokens->Head; It; It = It->Next)
	{
		TToken *Token = (TToken*)It->Data;
		if (Token->Type == instruction)
		{
			AssembleInstruction(&It, LabelMap, DependentInstructions, Memory, &Index);
		}
		else if (Token->Type == directive)
		{
			PerformDirective(&It, LabelMap, DependentValues, Memory, &Index);
		}
		else if (Token->Type == label)
		{
			///In case the token is a label still not defined, defines its address.
			if (!RBTreeFind(LabelMap, Token->Text))
			{
				RBTreeInsert(LabelMap, NewString(Token->Text), NewInt(Index));
			}
			else
			{
				Error(Token->Line, Token->Text, ": Label already defined. 41");
			}
		}
		else
		{
			Error(Token->Line, Token->Text, ": Token unexpected. 42");
		}
	}
	///Resolves dependencies.
	ReplaceAddresses(LabelMap, DependentInstructions, Memory);
	ReplaceValues(LabelMap, DependentValues, Memory);
	///And completes missing half words.
	CompleteMemory(Memory);
}

void Export(RBTree *Memory, const char *Address)
{
	///If file opening is not successfull, stdout is used.
	FILE *F = stdout;
	if (Address)
	{
		F = fopen(Address, "w");
	}
	///For each word in Memory
	for (RBTreeIterator It = Memory->Begin; It; It = RBTreeNextIterator(Memory, It))
	{
		///Writes it properly to the output stream.
		int Index = *(int*)(It->Key);
		TWord *Word = (TWord*)(It->Data);
		fprintf(F, "%03X ", (Index >> 1 & 0xFFF));
		fprintf(F, "%02X %03X ", (Word->OpCode & 0xFF), (Word->Address & 0xFFF));
		It = RBTreeNextIterator(Memory, It);
		Word = (TWord*)(It->Data);
		fprintf(F, "%02X %03X\n", (Word->OpCode & 0xFF), (Word->Address & 0xFFF));
	}
	///And closes the stream.
	fflush(F);
	fclose(F);
}

int main(int ArgC, char *ArgV[])
{
	/// \note There must be at least one valid parameter, the input file path.
	if (ArgC < 2)
	{
		Error(-1, NULL, "Fatal error, no input file. 43");
	}
	///Allocates TList to keep tokens.
	TList *Tokens = ConstructList((void(*)(void*))TokenDestructor);
	///Reads and pre-processes input file.
	ReadFile(Tokens, ArgV[1]);
	PreProcessing(Tokens);
	///Allocates necessary RBTrees.
	RBTree *LabelMap = ConstructRBTree(StringComparator, free, free);
	RBTree *DependentInstructions = ConstructRBTree(StringComparator, free, (void(*)(void*))ListDestruct);
	RBTree *DependentValues = ConstructRBTree(StringComparator, free, (void(*)(void*))ListDestruct);
	RBTree *Memory = ConstructRBTree(IntComparator, free, free);
	///Performs assembly.
	Assemble(Tokens, LabelMap, DependentInstructions, DependentValues, Memory);
	///Exports generated memory map.
	Export(Memory, (ArgC > 2 ? ArgV[2] : NULL));
	/// Releases all alloc'ed memory.
	ListDestruct(Tokens);
	RBTreeDestruct(LabelMap);
	RBTreeDestruct(DependentInstructions);
	RBTreeDestruct(DependentValues);
	RBTreeDestruct(Memory);
	/// \return Everybodys is happy after all! :)
	return 0;
}

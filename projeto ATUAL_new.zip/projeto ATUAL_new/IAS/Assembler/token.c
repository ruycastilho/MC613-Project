/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file token.c
/// \author Renan Sterle - R.A.: 176536
/// \brief Implements TToken data type and related routines used by IAS assembler.
///

#include "token.h"

TToken *NewTokenA(TToken *Base)
{
	///Allocates New token and copies the original Base token.
	if (Base)
	{
		TToken *New = (TToken*)malloc(sizeof(TToken));
		New->Text = (char*)malloc((strlen(Base->Text)+1)*sizeof(char));
		strcpy(New->Text, Base->Text);
		New->Line = Base->Line;
		New->Type = Base->Type;
		return New;
	}
	return NULL;
}

TToken *NewTokenB(char *String, int Line)
{
	///Allocates New token and initializes its fields.
	/// \note ClassifyToken is performed to determine the new token type.
	TToken *New = (TToken*)malloc(sizeof(TToken));
	New->Text = (char*)malloc((strlen(String)+1)*sizeof(char));
	strcpy(New->Text, String);
	New->Line = Line;
	New->Type = ClassifyToken(&(New->Text), Line);
	return New;
}

TToken *NewTokenC(char *String, int Line, TokenType Type)
{
	///Allocates and initializes new token given its text, original line number and type.
	TToken *New = (TToken*)malloc(sizeof(TToken));
	New->Text = (char*)malloc((strlen(String)+1)*sizeof(char));
	strcpy(New->Text, String);
	New->Line = Line;
	New->Type = Type;
	return New;
}

void TokenDestructor(TToken *Target)
{
	//Deallocates token and its text.
	if (Target)
	{
		free(Target->Text);
		free(Target);
	}
}

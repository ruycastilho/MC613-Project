/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file rbtree.h
/// \author Renan Sterle - R.A.: 176536
/// \brief Specifies implementation of RBTreeNode and RBTree data types used by IAS assembler.
/// \note THIS FILE HAS BEEN RECYCLED FROM MC102
///

#ifndef RBTREE_H
#define RBTREE_H

#include <stdlib.h>
#include <stdbool.h>

///
/// \brief Elementary element of RBTree. Points to its parent and sons, and to data and key as well.
///
typedef struct RBTreeNode
{
	void *Key, *Data;
	struct RBTreeNode *Left, *Right, *Parent;
	bool Red;
} RBTreeNode, *RBTreeIterator;

///
/// \brief Red-Black binary search tree.
///
typedef struct RBTree
{
	int Size;
	int (*Comparator)(void* A, void* B);
	void (*KeyDestructor)(void* A), (*DataDestructor)(void* A);
	RBTreeIterator Root, NIL, Begin;
} RBTree;

///
/// \brief ConstructRBTree allocates and initializes RBTree establishing its comparator, key
///	destructor and data destructor functions.
/// \return Pointer to new alloc'ed RBTree.
///
RBTree *ConstructRBTree(int(*Comparator)(void*, void*),
					void (*KeyDestructor)(void*), void (*DataDestructor)(void*));

///
/// \brief RBTreeInsert inserts element on Tree, or updates it, if the tree already contains and
/// an entry for Key.
/// \param Tree pointer to RBTree to have the element inserted.
/// \param Key of the element to be inserted.
/// \param Data of the element to be inserted.
/// \return Pointer to new alloc'ed RBTree.
///
RBTreeIterator RBTreeInsert(RBTree *Tree, void *Key, void *Data);

///
/// \brief TreeInsert internal insertion function. Not intended to be invoked directly.
///
void TreeInsert(RBTree *Tree, RBTreeIterator Node);

///
/// \brief NodeRotateLeft internal rotation function. Not intended to be invoked directly.
///
void NodeRotateLeft(RBTree *Tree, RBTreeIterator Node);

///
/// \brief NodeRotateRight internal rotation function. Not intended to be invoked directly.
///
void NodeRotateRight(RBTree *Tree, RBTreeIterator Node);

///
/// \brief RBTreeNextIterator advances Node iterator in-order on Tree.
/// \param Tree tree to wich Node belongs.
/// \param Node base iterator.
/// \return Iterator pointin to Node's next position.
///
RBTreeIterator RBTreeNextIterator(RBTree *Tree, RBTreeIterator Node);

///
/// \brief TreeDestruct internal deallocation function. Not intended to be invoked directly.
///
void TreeDestruct(RBTree *Tree, RBTreeIterator Node);

///
/// \brief RBTreeDestruct deallocates memory used by Tree.
/// \param Tree to be destroyed.
///
void RBTreeDestruct(RBTree *Tree);

///
/// \brief RBTreeFind looks for Key on Tree.
/// \param Tree tree in which Key is searched for.
/// \param Key searched in Tree.
/// \return Iterator to TreeNode corresponding to Key, if it exists. NULL, otherwise.
///
RBTreeIterator RBTreeFind(RBTree *Tree, void *Key);
#endif

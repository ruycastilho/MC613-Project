/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file rbtree.c
/// \author Renan Sterle - R.A.: 176536
/// \brief Implements RBTreeNode and RBTree data types and related routines used by IAS assembler.
/// \note THIS RB-TREE IMPLEMENTATION HAS BEEN RECYCLED FROM MC102, AND HAS BEEN ONLY SLIGHTLY REVISED.
///

#include "rbtree.h"

RBTree *ConstructRBTree(int(*Comparator)(void*, void*),	void (*KeyDestructor)(void*), void (*DataDestructor)(void*))
{
	///Allocates and initializes tree and sentinels.
	RBTree *Tree = (RBTree*)malloc(sizeof(RBTree));
	Tree->Comparator = Comparator;
	Tree->KeyDestructor = KeyDestructor;
	Tree->DataDestructor = DataDestructor;
	Tree->Size = 0;
	RBTreeIterator Node = Tree->NIL = (RBTreeNode*)malloc(sizeof(RBTreeNode));
	Node->Parent = Node->Left = Node->Right = Node;
	Node->Red = false;
	Node->Key = NULL;
	Node = Tree->Root = (RBTreeNode*)malloc(sizeof(RBTreeNode));
	Tree->Begin = NULL;
	Node->Parent = Node->Left = Node->Right = Tree->NIL;
	Node->Key = NULL;
	Node->Red = false;
	///Return pointer to new alloc'ed tree.
	return Tree;
}

RBTreeIterator RBTreeInsert(RBTree *Tree, void *Key, void *Data)
{
	///If element already exists, updates its data.
	RBTreeIterator A = RBTreeFind(Tree, Key);
	if (A)
	{
		Tree->KeyDestructor(Key);
		Tree->DataDestructor(A->Data);
		A->Data = Data;
		return A;
	}
	///Is necessary to insert new node.
	Tree->Size++;
	///Allocates and initializes new node.
	A =	(RBTreeNode*)malloc(sizeof(RBTreeNode));
	RBTreeIterator B, New;
	A->Key = Key;
	A->Data = Data;
	///And seeks the proper position to insert it.
	TreeInsert(Tree, A);
	New = A;
	///Fixes tree after insertion.
	A->Red = true;
	while(A->Parent->Red)
	{
		if (A->Parent == A->Parent->Parent->Left)
		{
			/*
			 *     *
			 *    / \
			 *   *   B
			 *  /
			 * A
			*/
			B = A->Parent->Parent->Right;
			if (B->Red)
			{
				A->Parent->Red = false;
				B->Red= false;
				A->Parent->Parent->Red = true;
				A = A->Parent->Parent;
			}
			else
			{
				/*
				 * *
				 *  \
				 *   A
				*/
				if (A == A->Parent->Right)
				{
					A = A->Parent;
					NodeRotateLeft(Tree, A);
				}
				A->Parent->Red = false;
				A->Parent->Parent->Red = true;
				NodeRotateRight(Tree, A->Parent->Parent);
			}
		}
		else
		{
			/*
			 *   *
			 *  / \
			 * B   *
			 *      \
			 *       A
			*/
			B = A->Parent->Parent->Left;
			if (B->Red)
			{
				A->Parent->Red = false;
				B->Red = false;
				A->Parent->Parent->Red = true;
				A = A->Parent->Parent;
			}
			else
			{
				/*
				 *   *
				 *  /
				 * A
				*/
				if (A == A->Parent->Left)
				{
					A = A->Parent;
					NodeRotateRight(Tree, A);
				}
				A->Parent->Red = false;
				A->Parent->Parent->Red = true;
				NodeRotateLeft(Tree, A->Parent->Parent);
			}
		}
	}
	Tree->Root->Left->Red = false;
	if (!Tree->Begin || Tree->Comparator(Tree->Begin->Key, New->Key) > 0)
	{
		Tree->Begin = New;
	}
	return New;
}

void TreeInsert(RBTree *Tree, RBTreeIterator Node)
{
	///Inserts Node at the correct position in Tree.
	RBTreeIterator A, B;
	Node->Left = Node->Right = Tree->NIL;
	B = Tree->Root;
	A = B->Left;
	///Binary search.
	while(A != Tree->NIL)
	{
		B = A;
		if (Tree->Comparator(A->Key,Node->Key) > 0)
		{
			A = A->Left;
		}
		else
		{
			A = A->Right;
		}
	}
	///Node position definition.
	Node->Parent = B;
	if ((B == Tree->Root) || (Tree->Comparator(B->Key, Node->Key) > 0))
	{
		B->Left = Node;
	}
	else
	{
		B->Right = Node;
	}
}

void NodeRotateLeft(RBTree *Tree, RBTreeIterator Node)
{
	///Left rotation around Node.
	RBTreeIterator A = Node->Right;
	Node->Right = A->Left;
	if (Tree->NIL != A->Left)
	{
		A->Left->Parent = Node;
	}
	A->Parent = Node->Parent;
	if (Node == Node->Parent->Left)
	{
		Node->Parent->Left = A;
	}
	else
	{
		Node->Parent->Right = A;
	}
	A->Left = Node;
	Node->Parent = A;
}

void NodeRotateRight(RBTree *Tree, RBTreeIterator Node)
{
	///Right rotation around Node.
	RBTreeNode* A = Node->Left;
	Node->Left = A->Right;
	if (Tree->NIL != A->Right)
	{
		A->Right->Parent = Node;
	}
	A->Parent = Node->Parent;
	if (Node == Node->Parent->Left)
	{
		Node->Parent->Left = A;
	}
	else
	{
		Node->Parent->Right = A;
	}
	A->Right = Node;
	Node->Parent = A;
}

RBTreeIterator RBTreeNextIterator(RBTree *Tree, RBTreeIterator Node)
{
	///Returns next iterator in order.
	RBTreeIterator A;
	if (Node->Right != Tree->NIL)
	{
		///Returns leftmost element of right subtree.
		A = Node->Right;
		while (A->Left != Tree->NIL)
		{
			A = A->Left;
		}
		if (A != Tree->NIL)
		{
			return A;
		}
		else
		{
			return NULL;
		}
	}
	else
	{
		///Is there is no right subtree, goes up to find one.
		A = Node->Parent;
		while (Node == A->Right && A != Tree->NIL)
		{
			Node = A;
			A = A->Parent;
		}
		if (A == Tree->Root || A == Tree->NIL)
		{
			return NULL;
		}
		return A;
	}
	return NULL;
}

void  TreeDestruct(RBTree *Tree, RBTreeIterator Node)
{
	if (Node != Tree->NIL)
	{
		///Recursive destruction of Tree nodes.
		TreeDestruct(Tree, Node->Left);
		TreeDestruct(Tree, Node->Right);
		Tree->KeyDestructor(Node->Key);
		Tree->DataDestructor(Node->Data);
		free(Node);
	}
}

void RBTreeDestruct(RBTree *Tree)
{
	if (Tree)
	{
		///Recursive destruction of Tree nodes.
		TreeDestruct(Tree, Tree->Root->Left);
		///Destruction of sentinels.
		free(Tree->Root);
		free(Tree->NIL);
		///Destruction of tree itself.
		free(Tree);
	}
}

RBTreeIterator RBTreeFind(RBTree* Tree, void *Key)
{
	///If tree is empty, returns NULL.
	RBTreeNode* Node = Tree->Root->Left;
	if (Node == Tree->NIL)
	{
		return NULL;
	}
	///Binary search on Tree looking for Key.
	int Comparison = Tree->Comparator(Node->Key, Key);
	while(Comparison)
	{
		if (Comparison > 0)
		{
			Node = Node->Left;
		}
		else
		{
			Node = Node->Right;
		}
		///If element isn't found.
		if (Node == Tree->NIL)
		{
			return NULL;
		}
		Comparison = Tree->Comparator(Node->Key, Key);
	}
	return Node;
}

/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file misc.h
/// \author Renan Sterle - R.A.: 176536
/// \brief Specifies implementation of miscellaneous routines used by IAS assembler.
///

#ifndef MISC_H
#define MISC_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdbool.h>

///
/// \brief Alphanumeric checks if string S is composed only of alphanumeric characters and is not
/// initiated by a digit.
/// \param S string to be checked.
/// \return True, if S is alphanumeric not initiated by a digit. Returns false otherwise.
///
bool Alphanumeric(char *S);

///
/// \brief IsNumber checks if String is a number in base Base. If Value is not NULL and String is a
///	number in base Base, Value is defined as Strings numeric value.
/// \param String string to be evaluated.
/// \param Base numeric base os String.
/// \param Value pointer to retrieve numeric value of String.
/// \return Return true if String is a number in base Base. Returns false otherwise.
///
bool IsNumber(char *String, int Base, long *Value);

///
/// \brief Substring updates String to a new string containing range of N characters starting from
/// Begin.
/// \param String base string.
/// \param Begin position of String.
/// \param N number of characters of string range.
///
void Substring(char **String, char *Begin, int N);

///
/// \brief LowerBound seeks in the range delimited by [Begin, End] of a sorted string vector for
/// key Key, performing a binary search.
/// \param Begin beginning of search range.
/// \param End end of search range.
/// \param Key string to be searched.
/// \return Return first position where Key would fit in the vector.
///
char **LowerBound (const char **Begin, const char **End, char *Key);

///
/// \brief NewInt allocates new int with value equal to Old.
/// \param Old value to initialize the new integer.
/// \return Pointer to new alloc'ed integer.
///
int *NewInt(int Old);

///
/// \brief NewString allocates new string equal to Old.
/// \param Old value to initialize the new string.
/// \return Pointer to new alloc'ed string.
///
char *NewString(char *Old);

///
/// \brief Wrapper of strcmp with void pointers.
///
int StringComparator(void *A, void *B);

///
/// \brief IntComparator analog to strcmp, but for integers.
/// \param A pointer to first operand.
/// \param B pointer to second operand.
/// \return 1 if A > B; -1 if A < B; 0 if A == B.
///
int IntComparator(void *A, void *B);

///
/// \brief Error displays error message properly and stops program.
/// \param Line original line number containing problematic part.
/// \param Context original problematic text.
/// \param Error string explaining context of error.
///
void Error(int Line, const char *Context, const char *Error);
#endif

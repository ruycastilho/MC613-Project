/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file token.h
/// \author Renan Sterle - R.A.: 176536
/// \brief Specifies implementation of TToken data type and TokenType enum used by IAS assembler.
///

#ifndef TOKEN_H
#define TOKEN_H

#include <stdlib.h>
#include <string.h>

///
/// \brief TokenType is an enum type used to classify tokens, note that they are "bit-independent".
///
typedef enum {invalid = 0, directive = 1, symbol = 2, label = 4, instruction = 8,
		address = 16, literal = 32, decimal = 64, hexadecimal = 128} TokenType;

///
/// \brief TToken represents a token with original line position, text and type.
///
typedef struct
{
	char *Text;
	int Line;
	TokenType Type;
} TToken;

///
/// \brief NewTokenA allocates and initializes a new token based on Base.
/// \param Base used to initialize token to be created.
/// \return Pointer to new token alloc'ed.
///
TToken *NewTokenA(TToken *Base);

///
/// \brief NewTokenB allocates and initializes a new token based on text and line. The type of the
///	new token is determined after token classification.
/// \param String used to initialize text.
/// \param Line used to initialize line.
/// \return Pointer to new token alloc'ed.
///
TToken *NewTokenB(char *String, int Line);

///
/// \brief NewTokenC allocates and initializes a new token base on text, line and type.
/// \param String
/// \param Line
/// \param Type
/// \return
///
TToken *NewTokenC(char *String, int Line, TokenType Type);

///
/// \brief TokenDestructor releases memory pointed by Target.
/// \param Target pointer to TToken to be destroyed.
///
void TokenDestructor(TToken *Target);

///
/// \brief ClassifyToken classifies token Token based on its text formatting.
/// \param Token to be classified.
/// \param Line original line containing Token
/// \return TokenType corresponding to Token type.
///
TokenType ClassifyToken(char **Token, int Line);
#endif

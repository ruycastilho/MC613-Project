/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file list.h
/// \author Renan Sterle - R.A.: 176536
/// \brief Specifies implementation of ListNode and TList data types used by IAS assembler.
///

#ifndef LIST_H
#define LIST_H

#include <stdlib.h>

///
/// \brief Elementary element of TList. Points to its next and previous nodes, and to data as well.
///
typedef struct ListNode
{
	struct ListNode *Next, *Previous;
	void *Data;
} ListNode, *ListIterator;

///
/// \brief Linked list abstraction.
///
typedef struct TList
{
	ListNode *Head, *Tail;
	void (*DataDestructor)(void* A);
} TList;

///
/// \brief ConstructList allocates and initializes a TList.
/// \return Returns pointer to new alloc'ed list.
///
TList *ConstructList(void(*Destructor)(void *));

///
/// \brief ListPushBack insterts new node at the end of List.
/// \param List list to be expanded.
/// \param Data used to initialize the new node.
///
void ListPushBack(TList *List, void *Data);

///
/// \brief ListErase erases element pointed by It in list List.
/// \param List containing elemento pointed by It.
/// \param It iteratator to element to be erase.
///
void ListErase(TList *List, ListIterator *It);

///
/// \brief ListDestruct deallocates all memory used by TList pointed by List.
/// \param List pointer to list to be destroyed.
///
void ListDestruct(TList *List);
#endif

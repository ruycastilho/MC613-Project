/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file assembler.h
/// \author Renan Sterle - R.A.: 176536
/// \brief Specifies implementation of routines used by IAS assembler.
///

#ifndef ASSEMBLER_H
#define ASSEMBLER_H

#include "list.h"
#include "misc.h"
#include "rbtree.h"
#include "token.h"
#include "word.h"

///
/// \brief Self explanatory constants intrinsic to the IAS computer and IAS assembly program files.
///
const int NumberDirectives = 5, NumberInstructions = 17, MemorySize = 2048;
const char *Directives[] = {".align", ".org", ".set", ".wfill", ".word"};
const char *Instructions[] = {"ADD", "ADD|", "DIV", "JMP", "JUMP+", "LD", "LD-", "LDmq", "LDmq_mx",
										"LD|", "LSH", "MUL", "RSH", "ST", "STaddr", "SUB", "SUB|"};
const int OpCodes[] = {5, 7, 12, 14, 16, 1, 2, 10, 9, 3, 20, 11, 21, 33, 19, 6, 8};
const size_t MaxLineLength = 8096;

///
/// \brief IsDirective checks if string	Directive is contained on directives set.
/// \param Directive string to be verified.
/// \return True if Directive is a directive. False otherwise.
///
bool IsDirective(char *Directive);

///
/// \brief IsInstruction checks if string Instruction is contained on instruction set.
/// \param Instruction string to be verified.
/// \return True if Instruction is an instruction. False otherwise.
///
bool IsInstruction(char *Instruction);

///
/// \brief GetOpCode retrives op. code of string Instruction.
/// \param Instruction instruction name.
/// \return Returns int equal to Instruction's op. code.
///
int GetOpCode(char *Instruction);

///
/// \brief VerifySentenceOrder verifies if the sentence from Begin til the end of the list is a valid
/// sentence, respecting order of tokens.
/// \param Begin iterator to the beginning of the sentence.
///
void VerifySentenceOrder(ListIterator Begin);

///
/// \brief ReadFile reads and tokenizes the file Adress to Tokens.
/// \param Tokens TList in wich tokens are stored.
/// \param Address address of input file.
///
void ReadFile(TList *Tokens, const char *Address);

///
/// \brief ClassifyToken finds out the TokenType of a token given by its text (Token).
/// \param Token tokens original text. Can be modified to be adequated.
/// \param Line number of original line containing the token.
/// \return
///
TokenType ClassifyToken(char **Token, int Line);

///
/// \brief PreProcessing Processes the list of tokens performing .set directive.
/// \param Tokens list of tokens.
///
void PreProcessing(TList *Tokens);

///
/// \brief AssembleInstruction assembles instruction indicated by It to the Index postion of Memory.
/// If the instructions address is a label, its address is retrieved from LabelMap. In case the label
/// is still not defined, a dependecy is registered in DependentInstructions.
/// \param It Iterator indicating current token.
/// \param LabelMap RBTree mapping labels to indexes.
/// \param DependentInstructions RBTree mapping labels and instructions with missing adress indexes;
/// \param Memory RBTree representing the memory map.
/// \param Index Index of memory map.
///
void AssembleInstruction(ListIterator *It, RBTree *LabelMap, RBTree *DependentInstructions, RBTree *Memory, int *Index);

///
/// \brief PerformDirective performs directive indicated by It on the position Index of Memory. If
///	the instruction depends of a label value, it is retrieved from LabelMap. In case the label is
/// still not defined, a dependecy is registered in DependentValues.
/// \param It Iterator indicating current token.
/// \param LabelMap RBTree mapping labels to indexes.
/// \param DependentValues RBTree mapping labels and missing constant values indexes;
/// \param Memory RBTree representing the memory map.
/// \param Index Index of memory map.
///
void PerformDirective(ListIterator *It, RBTree *LabelMap, RBTree *DependentValues,
																		RBTree *Memory, int *Index);

///
/// \brief ReplaceAddresses replaces all adresses in instructions not completed. If necessary,
/// updates op. code to match the address value.
/// \param LabelMap RBTree mapping labels to indexes.
/// \param DependentInstructions RBTree mapping labels and instructions with missing adress indexes;
/// \param Memory RBTree representing the memory map.
///
void ReplaceAddresses(RBTree *LabelMap, RBTree *DependentInstructions, RBTree *Memory);

///
/// \brief ReplaceValues replaces all value in words not dependedt of label not defined at the time
/// of directive performance.
/// \param LabelMap RBTree mapping labels to indexes.
/// \param DependentValues RBTree mapping labels and missing constant values indexes;
/// \param Memory RBTree representing the memory map.
///
void ReplaceValues(RBTree *LabelMap, RBTree *DependentValues, RBTree *Memory);

///
/// \brief CompleteMemory completes memory represented by Memory, fillig necessaur empty spaces with
/// zeroes.
/// \param Memory RBTree representing the memory map.
///
void CompleteMemory(RBTree *Memory);

////
/// \brief Assemble assembles the whole program, delegating tasks based on token types.
/// \param Tokens List of tokens.
/// \param LabelMap RBTree mapping labels to indexes.
/// \param DependentInstructions RBTree mapping labels and instructions with missing adress indexes;
/// \param DependentValues RBTree mapping labels and missing constant values indexes;
/// \param Memory RBTree representing the memory map.
///
void Assemble(TList *Tokens, RBTree *LabelMap, RBTree *DependentInstructions,
											  RBTree *DependentValues, RBTree *Memory);

///
/// \brief Export exports memory map defined by Memory to file Address or stdout, in case Adress NULL.
/// \param Memory RBTree representing the memory map.
/// \param Address path to output file.
///
void Export(RBTree *Memory, const char *Address);
#endif

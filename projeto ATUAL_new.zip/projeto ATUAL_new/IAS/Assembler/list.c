/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

///
/// \file list.c
/// \author Renan Sterle - R.A.: 176536
/// \brief Implements ListNode and TList data types and related routines used by IAS assembler.
///

#include "list.h"

TList *ConstructList(void(*Destructor)(void *))
{
	///Allocates and initilizes new list.
	TList *New = (TList*)malloc(sizeof(TList));
	New->Head = New->Tail = NULL;
	New->DataDestructor = Destructor;
	return New;
}

void ListPushBack(TList *List, void *Data)
{
	///Allocates and initializes the new node.
	ListNode *New = (ListNode*)malloc(sizeof(ListNode));
	New->Data = Data;
	///Is the list is not empty:
	if (List->Tail)
	{
		///Updates list's tail and head sentinels and node's sentinels.
		New->Previous = List->Tail;
		New->Next = NULL;
		List->Tail->Next = New;
		List->Tail = New;
	}
	///If the list is empty:
	else
	{
		///Updates list's tail and head sentinels and node's sentinels.
		List->Tail = New;
		List->Head = New;
		New->Previous = NULL;
		New->Next = NULL;
	}
}

void ListErase(TList *List, ListIterator *It)
{
	if (*It)
	{
		/// Rearrenges the pointers of previous and next nodes.
		if ((*It)->Previous)
		{
			ListIterator Iu = *It;
			Iu->Previous->Next = Iu->Next;
		}
		if ((*It)->Next)
		{
			(*It)->Next->Previous = (*It)->Previous;
		}
		///Rearrenges List tail and head sentinels.
		if (List->Head == *It)
		{
			List->Head = (*It)->Next;
		}
		if (List->Tail == *It)
		{
			List->Tail = (*It)->Previous;
		}
		///Releases the node and its data.
		ListIterator Iu = *It;
		*It = (*It)->Next;
		List->DataDestructor(Iu->Data);
		free(Iu);
	}
}

void ListDestruct(TList *List)
{
	if (List)
	{
		/// Iterates through List destroying its nodes.
		ListIterator A = List->Head, B;
		while (A)
		{
			B = A;
			A = A->Next;
			List->DataDestructor(B->Data);
			free(B);
		}
		/// And then the List itself.
		free(List);
	}
}

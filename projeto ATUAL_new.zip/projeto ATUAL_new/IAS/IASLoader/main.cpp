/*
MIT License

Copyright (c) 2016 Renan Adriani Sterle

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

#include <QCoreApplication>
#include <QtSerialPort/QtSerialPort>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

using namespace std;

void WriteWord(QSerialPort &Port, unsigned int Address, unsigned char Word[5])
{
    unsigned char Ch = 0;
    Port.write((char*)(&Ch), 1);
    Ch = (Address & 0xFF00) >> 8;
    Port.waitForBytesWritten(20);
    Port.write((char*)&Ch, 1);
    Port.waitForBytesWritten(20);
    Ch = (Address & 0xFF);
    Port.write((char*)&Ch, 1);
    Port.waitForBytesWritten(20);
    for (unsigned int J = 0; J < 5; J++)
    {
        Ch = Word[J];
        Port.write((char*)&Ch, 1);
        Port.waitForBytesWritten(20);
    }
}

int main(int ArgC, char *ArgV[])
{
    QCoreApplication Loader(ArgC, ArgV);
    QSerialPort Port;
    Port.setBaudRate(QSerialPort::Baud9600);
    if (ArgC > 2)
    {
        string Op = ArgV[2];
        Port.setPortName(ArgV[1]);
        Port.open(QIODevice::ReadWrite);
        if (Port.isOpen())
        {
            if (Op == "-R" || Op == "-W")
            {
                if (ArgC > 3)
                {
                    if (Op == "-R")
                    {
                        ofstream Os(ArgV[3]);
                        if (Os)
                        {
                            char Ch = (unsigned char)1, Line[5];
                            Port.readAll();
                            Port.clear();
                            Port.write(&Ch, 1);
                            for (int I = 0; I < 1024; I++)
                            {
                                for (int J = 0; J < 5; J++)
                                {
                                    Port.waitForReadyRead(20);
                                    Port.read(&Line[J], 1);
                                }
                                Os << hex << uppercase << ((I & 0xF00) >> 8) << ((I & 0x0F0) >> 4) << (I & 0x00F);
                                Os << ' ' << ((Line[0] & 0xF0) >> 4) << (Line[0] & 0x0F);
                                Os << ' ' << ((Line[1] & 0xF0) >> 4) << (Line[1] & 0x0F);
                                Os << ((Line[2] & 0xF0) >> 4) << ' ' <<  (Line[2] & 0x0F);
                                Os << ((Line[3] & 0xF0) >> 4) << ' ' <<  (Line[3] & 0x0F);
                                Os  << ((Line[4] & 0xF0) >> 4) << (Line[4] & 0x0F) << '\n';
                                cout << '\r' << I+1 << "/1024 words read (" << fixed << setprecision(2) << (I+1.0)/10.24 << "%)." << flush;
                            }
                            cout << '\n';
                            Os.flush();
                            Os.close();
                            Port.flush();
                            Port.close();
                            return 0;
                        }
                    }
                    else
                    {
                        ifstream Is(ArgV[3]);
                        if (Is)
                        {
                            unsigned int Address, ByteA, ByteB;
                            unsigned char Word[5], A, B;
                            int J = 1;
                            bool Map[1024] = {false};
                            for (int I = 0; I < 5; I++)
                            {
                                Word[I] = 0;
                            }
                            WriteWord(Port, 0, Word);
                            WriteWord(Port, 0, Word);
                            while (Is >> hex >> Address)
                            {
                                for (int I = 0; I < 5; I++)
                                {
                                    Is >> A >> B;
                                    stringstream SS;
                                    SS << A;
                                    SS >> hex >> ByteA;
                                    SS.clear();
                                    SS << B;
                                    SS >> hex >> ByteB;
                                    Word[I] = (ByteA << 4) + ByteB;
                                }
                                Map[Address] = true;
                                WriteWord(Port, Address, Word);
                                cout << '\r' << J << "/1024 words written (" << fixed << setprecision(2) << (J)/10.24 << "%)." << flush;
                                J++;
                            }
                            for (int I = 0; I < 5; I++)
                            {
                                Word[I] = 0;
                            }
                            for (int I = 0; I < 1024; I++)
                            {
                                if (!Map[I])
                                {
                                    WriteWord(Port, I, Word);
                                    cout << '\r' << J << "/1024 words written (" << fixed << setprecision(2) << (J)/10.24 << "%)." << flush;
                                    J++;
                                }
                            }
                            cout << '\n';
                            Is.close();
                            Port.flush();
                            Port.close();
                            return 0;
                        }
                    }
                }
            }
            else if (Op == "-C")
            {
                Port.readAll();
                Port.clear();
                for (unsigned int I = 0; I < 1024; I++)
                {
                    unsigned char Ch[5]	= {0};
                    WriteWord(Port, I, Ch);
                    cout << '\r' << I+1 << "/1024 words cleared (" << fixed << setprecision(2) << (I+1.0)/10.24 << "%)." << flush;
                }
                cout << '\n';
                Port.flush();
                Port.close();
                return 0;
            }
        }
        else
        {
            cout << "Port could not be opened.\n";
            return 1;
        }
    }
    cout << "Usage: IASLoader <PortName> -R|-W|-C <File>\n"
            "\t-R: Read memory map to file;\n"
            "\t-W: Write memory map from file;\n"
            "\t-C: Clear IAS memory;\n";
    return 1;
}

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
	float theta[28 * 28];
	int i, j, k;
	float predict[1000][10];
	int actual_result[10000];	
	int images[1000][28*28];
	int result[1000][10];
	int number = 1000;
	int n_images = 0;
	int sum;

	//get parameters
	FILE *p = fopen(argv[1], "r");
	while(fscanf(p, "%d", &actual_result[n_images]) != EOF && n_images > 999){
		for(i = 0; i < 28 * 28; i++)
			fscanf(p, "%d", &images[n_images][i]);
		printf("%d\n", n_images);
		n_images++;			
	}
	for(i = 0; i < n_images; i++)
		printf("%d\n", actual_result[i]);
	printf("%d\n", n_images);
	/*

	//initialize theta
	for(i = 0; i < 28 * 28; i++)
		theta[i] = (rand()/1000) % 5;

	while(number > 0){
		//prediction
		for(i = 0; i < n_images; i++)
			for(j = 0; j < 10; j++){
				predict[i][j] = 0;
				for(k = 0; k < 28 * 28; k++)
					predict[i][j] += theta[k] * images[i][k];
			}

		//atualizates theta
		for(i = 0; i < 28 * 28; i++){
			sum = 0;
			for(j = 0; j < n_images; j++)
				for(k = 0; k < 10; k++)
					sum += (predict[j][k] - result[j][k]) * images[j][k];	
		}
		number--;
	}
		
		

	

	for(i = 0; i < 28 * 28; i++)
		printf("%d ", theta[i]);*/

	return 0;

	
	
}
